// UK lang variables/* Remember to namespace the language parameters lang_<your plugin>_<some name> *//r//Older tiny2 lang file. Can be deleted
